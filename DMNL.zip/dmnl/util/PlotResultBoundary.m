function PlotResultBoundary(F,X_bound_data,maxx, minx)
PlotData(X_bound_data,F,maxx, minx);
end