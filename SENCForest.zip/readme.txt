Description: The package includes the MATLAB code of the algorithm SENCForest. We show a simple example on synthetic data, the detail of synthetic data is described in the paper. The goal is to show algorithm is efficient. This is the version 1, and it will be constantly improved. We will update the progress in http://lamda.nju.edu.cn/mux/.

Step 1. input "data.mat" as synthic data;  Step 2. run Main_process.m.

Reference: X. Mu, K. M. Ting, and Z.-H. Zhou. Classification under streaming emerging new classes: A solution using completely-random trees. IEEE Transactions on Knowledge and Data Engineering, in press.

ATTN: This packages were developed by Xin Mu (mux@lamda.nju.edu.cn). For any problem and suggestment, please feel free to contact Mr. Mu.